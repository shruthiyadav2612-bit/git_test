"""
phishing_detector.py
Rule-based detection of phishing / scam / social-engineering language.
Every match includes a human-readable reason, in line with the
"explainable AI" requirement — no bare probability numbers.
"""

from __future__ import annotations

import re

CATEGORY_PATTERNS: dict[str, list[str]] = {
    "urgent_payment": [
        r"\bpay(ment)? (immediately|now|within)\b", r"\boutstanding (invoice|payment)\b",
        r"\bwire transfer\b", r"\bfinal notice\b", r"\boverdue\b",
    ],
    "account_suspension": [
        r"\baccount (will be |has been )?(suspended|locked|disabled|terminated)\b",
        r"\bverify your account\b", r"\bunusual (sign-?in|login) activity\b",
        r"\bconfirm your identity\b",
    ],
    "credential_otp_request": [
        r"\bpassword\b.{0,20}\b(expire|reset|confirm)\b", r"\bone[- ]?time password\b",
        r"\botp\b", r"\benter your (pin|password|otp)\b", r"\bclick here to (verify|login|reset)\b",
    ],
    "banking_payment_request": [
        r"\bbank (account|details)\b", r"\bupdate (your )?billing\b", r"\bcard (number|details) (required|needed)\b",
        r"\bupi id\b", r"\bswift code\b",
    ],
    "prize_lottery_scam": [
        r"\byou('| ha)ve won\b", r"\blottery\b", r"\bclaim your prize\b", r"\bcongratulations you\b",
        r"\bselected winner\b",
    ],
    "fake_job_offer": [
        r"\bwork from home\b.{0,30}\bearn\b", r"\bpart[- ]?time job\b.{0,30}\b(daily|weekly) (income|payment)\b",
        r"\bno experience (required|needed)\b.{0,30}\bhigh (salary|pay)\b", r"\brecruitment fee\b",
    ],
    "fake_government_message": [
        r"\bincome tax (refund|department)\b", r"\bcustoms (duty|clearance)\b", r"\bgovernment grant\b",
        r"\blegal action will be taken\b", r"\bwarrant (for your arrest|issued)\b",
    ],
    "investment_scam": [
        r"\bguaranteed returns?\b", r"\bdouble your (money|investment)\b", r"\bforex trading\b.{0,20}\bprofit\b",
        r"\bexclusive investment opportunity\b",
    ],
    "cryptocurrency_scam": [
        r"\bbitcoin\b.{0,30}\b(send|transfer|wallet)\b", r"\bcrypto(currency)? giveaway\b",
        r"\bwallet (seed phrase|private key)\b", r"\bdouble your (btc|bitcoin|crypto)\b",
    ],
    "impersonation": [
        r"\bthis is (your|the) ceo\b", r"\bon behalf of\b.{0,20}\b(ceo|director|manager)\b",
        r"\bkeep this (confidential|between us)\b", r"\bi need you to handle this discreetly\b",
    ],
    "social_engineering_urgency": [
        r"\bact (now|immediately)\b", r"\bwithin 24 hours\b", r"\bfailure to (respond|comply)\b",
        r"\bthis is urgent\b", r"\bdo not (tell|inform) anyone\b",
    ],
}

CATEGORY_LABELS = {
    "urgent_payment": "Urgent payment request",
    "account_suspension": "Account suspension / verification threat",
    "credential_otp_request": "Password / OTP credential request",
    "banking_payment_request": "Banking or payment detail request",
    "prize_lottery_scam": "Prize / lottery scam language",
    "fake_job_offer": "Fake job offer pattern",
    "fake_government_message": "Fake government / legal threat",
    "investment_scam": "Investment scam language",
    "cryptocurrency_scam": "Cryptocurrency scam language",
    "impersonation": "Executive / authority impersonation",
    "social_engineering_urgency": "Artificial urgency / social engineering",
}


def detect_phishing_language(body_text: str, subject: str = "") -> dict:
    text = f"{subject}\n{body_text}".lower()
    matches = []
    categories_hit = set()

    for category, patterns in CATEGORY_PATTERNS.items():
        for pattern in patterns:
            found = re.search(pattern, text, re.IGNORECASE)
            if found:
                categories_hit.add(category)
                matches.append({
                    "category": category,
                    "label": CATEGORY_LABELS[category],
                    "matched_phrase": found.group(0),
                })
                break  # one match per category is enough to flag it

    classification = _classify(categories_hit)

    return {
        "categories_detected": sorted(categories_hit),
        "matches": matches,
        "classification": classification,
        "language_risk_points": min(len(categories_hit) * 10, 40),
    }


def _classify(categories: set) -> str:
    if "cryptocurrency_scam" in categories:
        return "Financial Scam"
    if "investment_scam" in categories or "banking_payment_request" in categories:
        return "Financial Scam"
    if "credential_otp_request" in categories or "account_suspension" in categories:
        return "Credential Theft"
    if "impersonation" in categories:
        return "Business Email Compromise"
    if "fake_job_offer" in categories:
        return "Social Engineering"
    if "fake_government_message" in categories:
        return "Impersonation"
    if categories:
        return "Phishing"
    return "Unknown"
