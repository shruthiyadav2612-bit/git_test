"""
email_parser.py
Parses raw email text (pasted or uploaded .eml/.txt) into a structured
representation: headers, body text, and attachment metadata.
Uses Python's built-in `email` package only — no external services.
"""

from __future__ import annotations

import hashlib
import re
from email import policy
from email.parser import BytesParser, Parser
from email.utils import getaddresses, parsedate_to_datetime
from typing import Any


def _safe_str(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def parse_raw_email(raw_text: str) -> dict:
    """
    Parse raw email source (headers + body, RFC 822 style) or plain pasted
    text that may only loosely resemble an email. Falls back gracefully
    when the input has no real headers (e.g. someone just pastes body text).
    """
    raw_text = raw_text or ""

    looks_like_email = bool(re.search(r"^[A-Za-z\-]+:\s?.+$", raw_text, re.MULTILINE)) and (
        "From:" in raw_text or "Subject:" in raw_text or "Received:" in raw_text
    )

    headers: dict[str, str] = {}
    body_text = raw_text
    attachments: list[dict] = []
    received_chain: list[str] = []
    message_id = ""

    if looks_like_email:
        try:
            msg = Parser(policy=policy.default).parsestr(raw_text)
            headers = {k: _safe_str(v) for k, v in msg.items()}
            received_chain = [_safe_str(v) for v in msg.get_all("Received", [])]
            message_id = _safe_str(msg.get("Message-ID", ""))

            body_parts = []
            if msg.is_multipart():
                for part in msg.walk():
                    content_disposition = str(part.get("Content-Disposition") or "")
                    filename = part.get_filename()
                    if filename:
                        try:
                            payload = part.get_payload(decode=True) or b""
                        except Exception:
                            payload = b""
                        attachments.append({
                            "filename": filename,
                            "content_type": part.get_content_type(),
                            "size": len(payload),
                            "sha256": hashlib.sha256(payload).hexdigest() if payload else "",
                        })
                    elif part.get_content_type() in ("text/plain", "text/html") and "attachment" not in content_disposition:
                        try:
                            payload = part.get_content()
                        except Exception:
                            payload = ""
                        body_parts.append(_safe_str(payload))
            else:
                try:
                    body_parts.append(_safe_str(msg.get_content()))
                except Exception:
                    body_parts.append(_safe_str(msg.get_payload()))

            body_text = "\n".join(body_parts) if body_parts else raw_text
        except Exception:
            # Fall back to treating the whole thing as unstructured text.
            looks_like_email = False

    from_addr_list = getaddresses([headers.get("From", "")]) if headers.get("From") else []
    reply_to_list = getaddresses([headers.get("Reply-To", "")]) if headers.get("Reply-To") else []
    return_path_list = getaddresses([headers.get("Return-Path", "")]) if headers.get("Return-Path") else []

    from_name, from_email = (from_addr_list[0] if from_addr_list else ("", ""))
    reply_name, reply_email = (reply_to_list[0] if reply_to_list else ("", ""))
    _, return_path_email = (return_path_list[0] if return_path_list else ("", ""))

    date_str = headers.get("Date", "")
    parsed_date = None
    if date_str:
        try:
            parsed_date = parsedate_to_datetime(date_str).isoformat()
        except Exception:
            parsed_date = date_str

    return {
        "is_structured_email": looks_like_email,
        "headers": headers,
        "message_id": message_id,
        "date": parsed_date or date_str,
        "from_name": from_name,
        "from_email": from_email.lower(),
        "reply_to_email": reply_email.lower(),
        "return_path_email": return_path_email.lower(),
        "to": headers.get("To", ""),
        "subject": headers.get("Subject", ""),
        "received_chain": received_chain,
        "body_text": body_text,
        "attachments": attachments,
        "raw_length": len(raw_text),
    }
