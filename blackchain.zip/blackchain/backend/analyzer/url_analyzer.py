"""
url_analyzer.py
Extracts URLs from email body text and applies safe, passive heuristics
(no live requests are made to the URLs — nothing is "visited").
"""

from __future__ import annotations

import re
from urllib.parse import urlparse

URL_REGEX = re.compile(r"https?://[^\s\"'<>()\]]+", re.IGNORECASE)

SHORTENERS = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly",
    "rebrand.ly", "cutt.ly", "shorte.st", "adf.ly",
}

SUSPICIOUS_TLDS = {".zip", ".xyz", ".top", ".click", ".work", ".gq", ".tk", ".ml", ".cf"}

BRAND_KEYWORDS = ["paypal", "amazon", "apple", "microsoft", "google", "netflix", "bank", "irs", "gov"]


def _is_ip_host(host: str) -> bool:
    return bool(re.match(r"^\d{1,3}(\.\d{1,3}){3}$", host or ""))


def extract_urls(text: str) -> list[str]:
    return list(dict.fromkeys(URL_REGEX.findall(text or "")))  # de-duplicated, order preserved


def analyze_urls(text: str, sender_domain: str = "") -> list[dict]:
    urls = extract_urls(text)
    results = []

    for url in urls:
        parsed = urlparse(url)
        host = (parsed.hostname or "").lower()
        reasons = []
        risk = 0

        is_https = parsed.scheme == "https"
        if not is_https:
            reasons.append("Not using HTTPS")
            risk += 10

        is_ip_based = _is_ip_host(host)
        if is_ip_based:
            reasons.append("URL uses a raw IP address instead of a domain name")
            risk += 25

        is_shortener = host in SHORTENERS
        if is_shortener:
            reasons.append("Known URL-shortener service — real destination is hidden")
            risk += 15

        has_suspicious_chars = bool(re.search(r"[@]|%[0-9a-fA-F]{2}.*%[0-9a-fA-F]{2}", url)) or url.count("-") > 4
        if "@" in url:
            reasons.append("Contains '@', which can be used to disguise the real destination")
            risk += 20
        if url.count("-") > 4:
            reasons.append("Unusually many hyphens in the URL, common in phishing domains")
            risk += 5

        suspicious_tld = any(host.endswith(tld) for tld in SUSPICIOUS_TLDS)
        if suspicious_tld:
            reasons.append("Uses a top-level domain frequently abused for phishing/spam")
            risk += 15

        domain_mismatch = False
        if sender_domain and host and sender_domain not in host and not host.endswith(sender_domain):
            # only flag as mismatch if it also references a brand it doesn't belong to
            for brand in BRAND_KEYWORDS:
                if brand in host and brand not in sender_domain:
                    domain_mismatch = True
                    reasons.append(f"Link domain references '{brand}' but does not match the sender's domain")
                    risk += 20
                    break

        risk = min(risk, 100)
        if risk >= 60:
            level = "High"
        elif risk >= 30:
            level = "Medium"
        elif risk > 0:
            level = "Low"
        else:
            level = "Clean"

        results.append({
            "url": url,
            "domain": host,
            "https": is_https,
            "ip_based": is_ip_based,
            "shortener": is_shortener,
            "suspicious_chars": has_suspicious_chars,
            "domain_mismatch": domain_mismatch,
            "suspicious_tld": suspicious_tld,
            "risk_score": risk,
            "risk_level": level,
            "reasons": reasons if reasons else ["No obvious indicators detected"],
        })

    return results
