"""
attachment_analyzer.py
Evaluates attachment metadata already extracted by email_parser.
Attachments are never executed or opened beyond metadata + hashing.
"""

from __future__ import annotations

DANGEROUS_EXTENSIONS = {
    ".exe", ".scr", ".bat", ".cmd", ".js", ".vbs", ".jar", ".ps1", ".msi",
    ".com", ".pif", ".hta", ".lnk", ".wsf",
}
RISKY_EXTENSIONS = {".zip", ".rar", ".7z", ".docm", ".xlsm", ".pptm", ".iso", ".img"}


def _extension_of(filename: str) -> str:
    if "." not in filename:
        return ""
    return "." + filename.rsplit(".", 1)[-1].lower()


def analyze_attachments(attachments: list[dict]) -> list[dict]:
    results = []
    for att in attachments:
        filename = att.get("filename", "unknown")
        ext = _extension_of(filename)
        size = att.get("size", 0)

        if ext in DANGEROUS_EXTENSIONS:
            risk = "High"
            note = f"Executable/script extension ({ext}) — frequently used to deliver malware."
        elif ext in RISKY_EXTENSIONS:
            risk = "Medium"
            note = f"Archive or macro-enabled file type ({ext}) — inspect contents before opening."
        elif ext in (".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx"):
            risk = "Low"
            note = "Common office/document format. Still verify sender before opening."
        else:
            risk = "Low" if ext else "Medium"
            note = "Unrecognized or missing extension." if not ext else "No specific indicators detected."

        results.append({
            "filename": filename,
            "extension": ext or "(none)",
            "mime_type": att.get("content_type", "unknown"),
            "size_bytes": size,
            "sha256": att.get("sha256", ""),
            "suspicious_extension": ext in DANGEROUS_EXTENSIONS,
            "risk_level": risk,
            "note": note,
        })
    return results
