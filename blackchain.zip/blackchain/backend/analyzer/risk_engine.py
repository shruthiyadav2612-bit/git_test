"""
risk_engine.py
Combines signals from header analysis, phishing-language detection,
URL analysis and attachment analysis into a single transparent,
explainable 0-100 risk score.
"""

from __future__ import annotations


def compute_risk(header_result: dict, phishing_result: dict, url_results: list[dict], attachment_results: list[dict]) -> dict:
    score = 0
    explanation = []  # list of {"label", "detail"} — the explainable checklist

    # --- Authentication failures ---
    auth_findings = [f for f in header_result.get("findings", []) if f["type"] in
                     ("spf_failure", "dkim_failure", "dmarc_failure")]
    if auth_findings:
        score += 20
        explanation.append({
            "label": "Authentication failure",
            "detail": "; ".join(f["message"] for f in auth_findings),
        })

    # --- Sender / domain mismatch & spoofing ---
    mismatch_findings = [f for f in header_result.get("findings", []) if f["type"] in
                          ("reply_to_mismatch", "return_path_mismatch", "display_name_spoofing", "typosquatting")]
    if mismatch_findings:
        score += 15
        explanation.append({
            "label": "Sender/domain mismatch or spoofing",
            "detail": "; ".join(f["message"] for f in mismatch_findings),
        })

    # --- Disposable / free provider (minor signal only) ---
    minor_findings = [f for f in header_result.get("findings", []) if f["type"] in ("disposable_domain",)]
    if minor_findings:
        score += 5
        explanation.append({
            "label": "Disposable email provider",
            "detail": "; ".join(f["message"] for f in minor_findings),
        })

    # --- Urgency / social engineering language ---
    if phishing_result.get("categories_detected"):
        score += min(len(phishing_result["categories_detected"]) * 10, 30)
        labels = ", ".join(m["label"] for m in phishing_result.get("matches", []))
        explanation.append({
            "label": "Urgency / social-engineering / scam language",
            "detail": f"Detected patterns: {labels}",
        })

    # --- Suspicious URLs ---
    high_risk_urls = [u for u in url_results if u["risk_level"] in ("High", "Medium")]
    if high_risk_urls:
        score += 20
        explanation.append({
            "label": "Suspicious URL detected",
            "detail": f"{len(high_risk_urls)} of {len(url_results)} link(s) show phishing-style indicators.",
        })

    # --- Malicious attachment indicators ---
    dangerous_attachments = [a for a in attachment_results if a["risk_level"] == "High"]
    if dangerous_attachments:
        score += 25
        explanation.append({
            "label": "Malicious attachment indicator",
            "detail": f"{len(dangerous_attachments)} attachment(s) use high-risk extensions "
                      f"({', '.join(a['extension'] for a in dangerous_attachments)}).",
        })

    score = min(score, 100)

    if score <= 20:
        level, summary = "LOW", "Safe"
    elif score <= 40:
        level, summary = "MODERATE", "Suspicious"
    elif score <= 60:
        level, summary = "SUSPICIOUS", "Suspicious"
    elif score <= 80:
        level, summary = "HIGH", "High Risk"
    else:
        level, summary = "CRITICAL", "Critical"

    classification = phishing_result.get("classification", "Unknown")
    if dangerous_attachments and classification == "Unknown":
        classification = "Malware"
    if high_risk_urls and classification == "Unknown":
        classification = "Suspicious Link"
    if not explanation:
        classification = "Unknown" if classification == "Unknown" else classification
        explanation.append({"label": "No significant indicators found", "detail": "No strong phishing or spoofing signals were detected in this message."})

    recommendations = _recommendations_for(level, classification)

    return {
        "risk_score": score,
        "risk_level": level,
        "risk_summary": summary,
        "classification": classification,
        "explanation": explanation,
        "recommendations": recommendations,
    }


def _recommendations_for(level: str, classification: str) -> list[str]:
    base = [
        "Do not click any links in this email unless you have independently verified them.",
        "Do not provide passwords, OTPs, or banking details in response to this email.",
        "Verify the sender through an independent channel (official website or phone number).",
    ]
    if level in ("HIGH", "CRITICAL"):
        base.append("Report the email to your organization's security team or IT department.")
        base.append("Block the sender/domain if the threat is confirmed.")
    if classification == "Malware":
        base.append("Do not open or run any attachments from this email.")
    if level in ("LOW",):
        base = [
            "No strong threat indicators were found, but always verify unexpected requests independently.",
            "Avoid sharing sensitive information over email regardless of apparent sender trust.",
        ]
    return base
