"""
header_analyzer.py
Forensic analysis of email headers: authentication results (SPF/DKIM/DMARC),
display-name spoofing, Reply-To / Return-Path mismatches, and a simplified
"hop" chain derived from Received headers.
"""

from __future__ import annotations

import re

DISPOSABLE_DOMAINS = {
    "mailinator.com", "tempmail.com", "10minutemail.com", "guerrillamail.com",
    "yopmail.com", "trashmail.com", "fakeinbox.com", "getnada.com", "throwawaymail.com",
}

FREE_PROVIDERS = {
    "gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "aol.com",
    "icloud.com", "protonmail.com", "mail.com", "zoho.com",
}


def _domain_of(email_addr: str) -> str:
    if "@" not in (email_addr or ""):
        return ""
    return email_addr.split("@")[-1].lower().strip()


def _extract_auth_result(auth_header: str, mechanism: str) -> str:
    """Pull spf=/dkim=/dmarc= result out of an Authentication-Results header."""
    if not auth_header:
        return "none"
    match = re.search(rf"{mechanism}=([a-zA-Z]+)", auth_header, re.IGNORECASE)
    return match.group(1).lower() if match else "none"


def analyze_headers(parsed: dict) -> dict:
    headers = parsed.get("headers", {})
    auth_results_header = headers.get("Authentication-Results", "")

    spf = _extract_auth_result(auth_results_header, "spf")
    dkim = _extract_auth_result(auth_results_header, "dkim")
    dmarc = _extract_auth_result(auth_results_header, "dmarc")

    # Some providers put SPF/DKIM in dedicated headers instead.
    if spf == "none" and headers.get("Received-SPF"):
        m = re.search(r"^(\w+)", headers.get("Received-SPF", ""))
        spf = m.group(1).lower() if m else spf

    from_email = parsed.get("from_email", "")
    reply_to_email = parsed.get("reply_to_email", "")
    return_path_email = parsed.get("return_path_email", "")
    from_name = parsed.get("from_name", "")

    from_domain = _domain_of(from_email)
    reply_domain = _domain_of(reply_to_email)
    return_path_domain = _domain_of(return_path_email)

    findings = []

    if reply_to_email and reply_domain and from_domain and reply_domain != from_domain:
        findings.append({
            "type": "reply_to_mismatch",
            "severity": "high",
            "message": f"Reply-To domain ({reply_domain}) differs from the From domain ({from_domain}). "
                       f"Replies would be routed away from the apparent sender.",
        })

    if return_path_email and return_path_domain and from_domain and return_path_domain != from_domain:
        findings.append({
            "type": "return_path_mismatch",
            "severity": "medium",
            "message": f"Return-Path domain ({return_path_domain}) differs from the From domain ({from_domain}). "
                       f"This can indicate the message was sent via an unrelated or spoofed infrastructure.",
        })

    if from_name and from_email:
        # Display-name spoofing: a well-known brand name paired with an unrelated domain.
        known_brands = ["paypal", "amazon", "microsoft", "apple", "google", "bank", "netflix", "irs", "hdfc", "sbi", "icici"]
        name_lower = from_name.lower()
        for brand in known_brands:
            if brand in name_lower and brand not in from_domain:
                findings.append({
                    "type": "display_name_spoofing",
                    "severity": "high",
                    "message": f"Display name references '{brand}' but the sending domain ({from_domain or 'unknown'}) "
                               f"is unrelated to that brand.",
                })
                break

    if from_domain in DISPOSABLE_DOMAINS:
        findings.append({
            "type": "disposable_domain",
            "severity": "medium",
            "message": f"Sender domain '{from_domain}' is a known disposable/temporary email provider.",
        })

    if from_domain in FREE_PROVIDERS:
        findings.append({
            "type": "free_provider",
            "severity": "low",
            "message": f"Sender uses a free consumer email provider ({from_domain}) rather than an organizational domain. "
                       f"Not inherently malicious, but worth noting for business-context emails.",
        })

    # Simple typosquat heuristic: domain very close to a well-known one but not exact.
    lookalike_targets = ["paypal.com", "amazon.com", "microsoft.com", "apple.com", "google.com", "bankofamerica.com"]
    for target in lookalike_targets:
        if from_domain and from_domain != target and _looks_like_typosquat(from_domain, target):
            findings.append({
                "type": "typosquatting",
                "severity": "high",
                "message": f"Sender domain '{from_domain}' closely resembles '{target}' and may be a typosquat.",
            })

    if spf in ("fail", "softfail"):
        findings.append({
            "type": "spf_failure",
            "severity": "high",
            "message": f"SPF check result: {spf}. The sending server is not authorized for this domain.",
        })
    if dkim == "fail":
        findings.append({
            "type": "dkim_failure",
            "severity": "high",
            "message": "DKIM signature verification failed, suggesting the message may have been altered or forged.",
        })
    if dmarc == "fail":
        findings.append({
            "type": "dmarc_failure",
            "severity": "high",
            "message": "DMARC alignment failed, meaning the message did not pass the domain owner's own authentication policy.",
        })

    # Build a simplified hop chain from Received headers (most recent first in raw email).
    hops = []
    for received in reversed(parsed.get("received_chain", [])):
        from_match = re.search(r"from\s+([^\s;()]+)", received, re.IGNORECASE)
        by_match = re.search(r"by\s+([^\s;()]+)", received, re.IGNORECASE)
        hops.append({
            "from": from_match.group(1) if from_match else "unknown",
            "by": by_match.group(1) if by_match else "unknown",
        })

    originating_ip = _extract_first_public_ip(parsed.get("received_chain", []))

    return {
        "spf": spf,
        "dkim": dkim,
        "dmarc": dmarc,
        "from_domain": from_domain,
        "reply_to_domain": reply_domain,
        "return_path_domain": return_path_domain,
        "hops": hops,
        "originating_ip": originating_ip,
        "findings": findings,
        "message_id": parsed.get("message_id", ""),
        "date": parsed.get("date", ""),
    }


def _looks_like_typosquat(domain: str, target: str) -> bool:
    """Very lightweight edit-distance-style heuristic, not a full Levenshtein."""
    base_target = target.split(".")[0]
    base_domain = domain.split(".")[0]
    if base_domain == base_target:
        return False
    if base_target in base_domain and len(base_domain) - len(base_target) <= 3:
        return True
    # single-character substitution check for equal-length strings
    if len(base_domain) == len(base_target):
        diffs = sum(1 for a, b in zip(base_domain, base_target) if a != b)
        return diffs == 1
    return False


PRIVATE_IP_PATTERNS = [
    re.compile(r"^10\."), re.compile(r"^192\.168\."), re.compile(r"^127\."),
    re.compile(r"^172\.(1[6-9]|2\d|3[0-1])\."), re.compile(r"^0\."), re.compile(r"^169\.254\."),
]


def _is_public_ip(ip: str) -> bool:
    return not any(p.match(ip) for p in PRIVATE_IP_PATTERNS)


def _extract_first_public_ip(received_chain: list[str]) -> str:
    ip_re = re.compile(r"\[?(\d{1,3}(?:\.\d{1,3}){3})\]?")
    for received in received_chain:
        for match in ip_re.findall(received):
            if _is_public_ip(match):
                return match
    return ""
