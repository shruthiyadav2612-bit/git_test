"""
ip_intelligence.py
Approximate NETWORK geolocation for a public IP address found in email
headers. This is never presented as the sender's exact physical location —
only as approximate network-level information (ISP, city-level estimate).

Uses ip-api.com's free endpoint by default (no key required, rate-limited).
If IP_INTEL_API_URL / IP_INTEL_API_KEY env vars are set, those are used
instead (e.g. ipinfo.io, ipgeolocation.io).
"""

from __future__ import annotations

import os

import httpx

IP_INTEL_API_URL = os.getenv("IP_INTEL_API_URL", "")
IP_INTEL_API_KEY = os.getenv("IP_INTEL_API_KEY", "")

DISCLAIMER = "Approximate network geolocation — not the sender's exact physical location."


async def lookup_ip(ip: str) -> dict:
    if not ip:
        return {"available": False, "message": "Location unavailable — no public sending IP found in headers."}

    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            if IP_INTEL_API_URL:
                url = IP_INTEL_API_URL.format(ip=ip)
                headers = {"Authorization": f"Bearer {IP_INTEL_API_KEY}"} if IP_INTEL_API_KEY else {}
                resp = await client.get(url, headers=headers)
                data = resp.json()
                return _normalize_generic(ip, data)
            else:
                # ip-api.com free tier (HTTP only, ~45 req/min)
                resp = await client.get(
                    f"http://ip-api.com/json/{ip}",
                    params={"fields": "status,message,country,regionName,city,isp,org,as,lat,lon,timezone,proxy,hosting"},
                )
                data = resp.json()
                if data.get("status") != "success":
                    return {"available": False, "message": "Location unavailable — lookup failed for this IP."}
                return {
                    "available": True,
                    "ip": ip,
                    "country": data.get("country", ""),
                    "region": data.get("regionName", ""),
                    "city": data.get("city", ""),
                    "isp": data.get("isp", ""),
                    "org": data.get("org", ""),
                    "asn": data.get("as", ""),
                    "latitude": data.get("lat"),
                    "longitude": data.get("lon"),
                    "timezone": data.get("timezone", ""),
                    "vpn_or_proxy": bool(data.get("proxy")) or bool(data.get("hosting")),
                    "disclaimer": DISCLAIMER,
                }
    except Exception:
        return {"available": False, "message": "Location unavailable — geolocation service could not be reached."}


def _normalize_generic(ip: str, data: dict) -> dict:
    return {
        "available": True,
        "ip": ip,
        "country": data.get("country", data.get("country_name", "")),
        "region": data.get("region", ""),
        "city": data.get("city", ""),
        "isp": data.get("org", data.get("isp", "")),
        "org": data.get("org", ""),
        "asn": data.get("asn", ""),
        "latitude": data.get("latitude"),
        "longitude": data.get("longitude"),
        "timezone": data.get("timezone", ""),
        "vpn_or_proxy": bool(data.get("privacy", {}).get("proxy")) if isinstance(data.get("privacy"), dict) else False,
        "disclaimer": DISCLAIMER,
    }
