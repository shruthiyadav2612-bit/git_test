"""
models.py
Lightweight dataclasses describing BlackChain's core entities. These mirror
the SQLite schema created in database.py and document the shape of data
moving through the analysis pipeline. The API itself uses Pydantic schemas
(schemas.py) for request/response validation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class EmailRecord:
    id: int | None
    from_email: str
    from_domain: str
    subject: str
    received_at: datetime | None = None


@dataclass
class AnalysisRecord:
    id: int | None
    email_id: int
    risk_score: int
    risk_level: str
    classification: str
    created_at: datetime | None = None


@dataclass
class CaseRecord:
    id: int | None
    case_id: str
    analysis_id: int | None
    email_summary: str
    risk_level: str
    threat_type: str
    status: str = "New"
    analyst_notes: str = ""
    created_at: datetime | None = None
    updated_at: datetime | None = None


@dataclass
class IndicatorRecord:
    id: int | None
    analysis_id: int
    type: str  # IP | Domain | URL | Email | Hash
    value: str
    source: str
    risk: str
    notes: str = ""


@dataclass
class ReportRecord:
    id: int | None
    analysis_id: int
    case_id: str | None
    generated_at: datetime | None = None
