"""
main.py
BlackChain — AI Email Threat & Digital Forensics Platform
FastAPI backend entrypoint.
"""

from __future__ import annotations

import os
import uuid
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
import io

from analyzer.email_parser import parse_raw_email
from analyzer.header_analyzer import analyze_headers
from analyzer.phishing_detector import detect_phishing_language
from analyzer.url_analyzer import analyze_urls
from analyzer.attachment_analyzer import analyze_attachments
from analyzer.ip_intelligence import lookup_ip
from analyzer.risk_engine import compute_risk
from services.ioc_extractor import build_ioc_table
from services.demo_data import DEMO_SAMPLES
from services.report_generator import generate_pdf_report
from database import init_db, db_cursor
from schemas import AnalyzeRequest, CaseCreateRequest, CaseUpdateRequest, ReportRequest

app = FastAPI(title="BlackChain API", version="1.0.0",
              description="AI-assisted email threat detection & digital forensics API.")

ALLOWED_ORIGINS = [o.strip() for o in os.getenv("ALLOWED_ORIGINS", "http://localhost:5500,http://127.0.0.1:5500").split(",") if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

MAX_UPLOAD_BYTES = 5 * 1024 * 1024  # 5 MB


@app.on_event("startup")
def _startup():
    init_db()


# ---------------------------------------------------------------------------
# Core analysis pipeline (shared by /analyze and /upload)
# ---------------------------------------------------------------------------
async def _run_analysis(raw_email: str, create_case: bool = False) -> dict:
    if not raw_email or not raw_email.strip():
        raise HTTPException(status_code=400, detail="Email content is empty. Paste an email or upload a file.")

    parsed = parse_raw_email(raw_email)
    header_result = analyze_headers(parsed)
    phishing_result = detect_phishing_language(parsed["body_text"], parsed.get("subject", ""))
    url_results = analyze_urls(parsed["body_text"], header_result.get("from_domain", ""))
    attachment_results = analyze_attachments(parsed.get("attachments", []))
    ip_result = await lookup_ip(header_result.get("originating_ip", ""))
    risk_result = compute_risk(header_result, phishing_result, url_results, attachment_results)
    iocs = build_ioc_table(parsed, header_result, url_results, attachment_results, ip_result)

    analysis = {
        **risk_result,
        "sender": {
            "from_name": parsed.get("from_name", ""),
            "from_email": parsed.get("from_email", ""),
            "from_domain": header_result.get("from_domain", ""),
            "reply_to_email": parsed.get("reply_to_email", ""),
            "return_path_email": parsed.get("return_path_email", ""),
            "subject": parsed.get("subject", ""),
            "date": parsed.get("date", ""),
        },
        "authentication": {
            "spf": header_result.get("spf"),
            "dkim": header_result.get("dkim"),
            "dmarc": header_result.get("dmarc"),
        },
        "header_analysis": header_result,
        "urls": url_results,
        "attachments": attachment_results,
        "ip_intelligence": ip_result,
        "indicators": iocs,
        "phishing_language": phishing_result,
        "is_structured_email": parsed.get("is_structured_email", False),
        "analyzed_at": datetime.now(timezone.utc).isoformat(),
    }

    # Persist to DB
    with db_cursor() as cur:
        cur.execute(
            "INSERT INTO emails (from_email, from_domain, subject) VALUES (?, ?, ?)",
            (parsed.get("from_email", ""), header_result.get("from_domain", ""), parsed.get("subject", "")),
        )
        email_id = cur.lastrowid
        cur.execute(
            "INSERT INTO analyses (email_id, risk_score, risk_level, classification) VALUES (?, ?, ?, ?)",
            (email_id, risk_result["risk_score"], risk_result["risk_level"], risk_result["classification"]),
        )
        analysis_id = cur.lastrowid
        for ioc in iocs:
            cur.execute(
                "INSERT INTO indicators (analysis_id, type, value, source, risk, notes) VALUES (?, ?, ?, ?, ?, ?)",
                (analysis_id, ioc["type"], ioc["value"], ioc["source"], ioc["risk"], ioc["notes"]),
            )

    analysis["analysis_id"] = analysis_id
    analysis["email_id"] = email_id

    case_id = None
    if create_case:
        case_id = f"CASE-{datetime.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"
        subject = parsed.get("subject", "(no subject)")
        with db_cursor() as cur:
            cur.execute(
                """INSERT INTO cases (case_id, analysis_id, email_summary, risk_level, threat_type, status)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (case_id, analysis_id, subject, risk_result["risk_level"], risk_result["classification"], "New"),
            )
    analysis["case_id"] = case_id

    return analysis


@app.post("/api/analyze")
async def analyze_email(req: AnalyzeRequest):
    return await _run_analysis(req.raw_email, req.create_case)


@app.post("/api/upload")
async def upload_email(file: UploadFile = File(...), create_case: bool = False):
    contents = await file.read()
    if len(contents) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File too large. Maximum size is 5 MB.")
    try:
        raw_text = contents.decode("utf-8", errors="replace")
    except Exception:
        raise HTTPException(status_code=400, detail="Could not read the uploaded file as text (.eml/.txt supported).")
    return await _run_analysis(raw_text, create_case)


@app.get("/api/demo-samples")
def get_demo_samples():
    return {key: {"label": v["label"]} for key, v in DEMO_SAMPLES.items()}


@app.post("/api/demo/{sample_key}")
async def analyze_demo(sample_key: str):
    sample = DEMO_SAMPLES.get(sample_key)
    if not sample:
        raise HTTPException(status_code=404, detail="Unknown demo sample.")
    result = await _run_analysis(sample["raw"], create_case=False)
    result["is_demo"] = True
    result["demo_label"] = sample["label"]
    return result


# ---------------------------------------------------------------------------
# Cases
# ---------------------------------------------------------------------------
@app.get("/api/cases")
def list_cases():
    with db_cursor() as cur:
        cur.execute("SELECT * FROM cases ORDER BY created_at DESC")
        rows = [dict(r) for r in cur.fetchall()]
    return {"cases": rows, "count": len(rows)}


@app.post("/api/cases")
def create_case(req: CaseCreateRequest):
    case_id = f"CASE-{datetime.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"
    with db_cursor() as cur:
        cur.execute(
            """INSERT INTO cases (case_id, analysis_id, email_summary, risk_level, threat_type, status, analyst_notes)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (case_id, req.analysis_id, req.email_summary, req.risk_level, req.threat_type, req.status, req.analyst_notes),
        )
    return {"case_id": case_id, "message": "Case created."}


@app.get("/api/cases/{case_id}")
def get_case(case_id: str):
    with db_cursor() as cur:
        cur.execute("SELECT * FROM cases WHERE case_id = ?", (case_id,))
        row = cur.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Case not found.")
    return dict(row)


@app.put("/api/cases/{case_id}")
def update_case(case_id: str, req: CaseUpdateRequest):
    fields, values = [], []
    if req.status is not None:
        fields.append("status = ?")
        values.append(req.status)
    if req.analyst_notes is not None:
        fields.append("analyst_notes = ?")
        values.append(req.analyst_notes)
    if req.threat_type is not None:
        fields.append("threat_type = ?")
        values.append(req.threat_type)
    if not fields:
        raise HTTPException(status_code=400, detail="No fields to update.")
    fields.append("updated_at = CURRENT_TIMESTAMP")
    values.append(case_id)
    with db_cursor() as cur:
        cur.execute(f"UPDATE cases SET {', '.join(fields)} WHERE case_id = ?", values)
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Case not found.")
    return {"message": "Case updated."}


# ---------------------------------------------------------------------------
# Statistics / dashboard
# ---------------------------------------------------------------------------
@app.get("/api/statistics")
def get_statistics():
    with db_cursor() as cur:
        cur.execute("SELECT COUNT(*) AS c FROM emails")
        total_emails = cur.fetchone()["c"]

        cur.execute("SELECT COUNT(*) AS c FROM analyses WHERE risk_level IN ('MODERATE','SUSPICIOUS','HIGH','CRITICAL')")
        suspicious = cur.fetchone()["c"]

        cur.execute("SELECT COUNT(*) AS c FROM analyses WHERE risk_level IN ('HIGH','CRITICAL')")
        high_risk = cur.fetchone()["c"]

        cur.execute("SELECT COUNT(*) AS c FROM analyses WHERE classification LIKE '%Phishing%'")
        phishing = cur.fetchone()["c"]

        cur.execute("SELECT COUNT(*) AS c FROM analyses WHERE classification LIKE '%Scam%'")
        scam = cur.fetchone()["c"]

        cur.execute("SELECT COUNT(*) AS c FROM indicators WHERE type = 'URL' AND risk IN ('High','Medium')")
        malicious_urls = cur.fetchone()["c"]

        cur.execute("SELECT COUNT(*) AS c FROM cases")
        cases_created = cur.fetchone()["c"]

        cur.execute("SELECT COUNT(*) AS c FROM reports")
        reports_generated = cur.fetchone()["c"]

        cur.execute("SELECT classification, COUNT(*) AS c FROM analyses GROUP BY classification")
        by_category = {r["classification"]: r["c"] for r in cur.fetchall()}

        cur.execute("SELECT risk_level, COUNT(*) AS c FROM analyses GROUP BY risk_level")
        risk_distribution = {r["risk_level"]: r["c"] for r in cur.fetchall()}

        cur.execute("SELECT DATE(created_at) AS d, COUNT(*) AS c FROM analyses GROUP BY DATE(created_at) ORDER BY d")
        over_time = [{"date": r["d"], "count": r["c"]} for r in cur.fetchall()]

        cur.execute("""SELECT type, notes, COUNT(*) AS c FROM indicators
                       WHERE risk IN ('High','Medium') GROUP BY type ORDER BY c DESC LIMIT 8""")
        top_indicators = [{"type": r["type"], "notes": r["notes"], "count": r["c"]} for r in cur.fetchall()]

    return {
        "total_emails_analyzed": total_emails,
        "suspicious_emails": suspicious,
        "high_risk_emails": high_risk,
        "phishing_detected": phishing,
        "scam_detected": scam,
        "malicious_urls": malicious_urls,
        "cases_created": cases_created,
        "reports_generated": reports_generated,
        "threats_by_category": by_category,
        "risk_distribution": risk_distribution,
        "emails_over_time": over_time,
        "top_indicators": top_indicators,
        "has_data": total_emails > 0,
    }


# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------
@app.post("/api/reports")
def generate_report(req: ReportRequest):
    with db_cursor() as cur:
        cur.execute("SELECT * FROM analyses WHERE id = ?", (req.analysis_id,))
        analysis_row = cur.fetchone()
        if not analysis_row:
            raise HTTPException(status_code=404, detail="Analysis not found. Run /api/analyze first.")
        cur.execute("SELECT * FROM indicators WHERE analysis_id = ?", (req.analysis_id,))
        indicators = [dict(r) for r in cur.fetchall()]
        cur.execute("INSERT INTO reports (analysis_id, case_id) VALUES (?, ?)", (req.analysis_id, req.case_id))

    # Minimal reconstruction for the PDF — full detail should be sent from the
    # frontend for a richer report; this endpoint supports report re-generation
    # from stored summary data.
    analysis = {
        "risk_score": analysis_row["risk_score"],
        "risk_level": analysis_row["risk_level"],
        "risk_summary": analysis_row["risk_level"].title(),
        "classification": analysis_row["classification"],
        "explanation": [{"label": "Stored analysis", "detail": "See indicators table for full detail."}],
        "header_analysis": {},
        "ip_intelligence": {"available": False, "message": "Not stored for historical reports."},
        "urls": [i for i in indicators if i["type"] == "URL"],
        "indicators": indicators,
        "recommendations": [
            "Do not click any links in this email unless independently verified.",
            "Do not provide passwords, OTPs, or banking details.",
            "Verify the sender through an independent channel.",
        ],
    }
    pdf_bytes = generate_pdf_report(analysis, req.case_id)
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=blackchain_report_{req.analysis_id}.pdf"},
    )


@app.post("/api/reports/full")
async def generate_full_report(payload: dict):
    """
    Generates a PDF directly from a full analysis object (as returned by
    /api/analyze), avoiding the need to re-fetch every detail from storage.
    This is the endpoint the frontend uses right after an analysis.
    """
    case_id = payload.pop("case_id", None)
    pdf_bytes = generate_pdf_report(payload, case_id)
    with db_cursor() as cur:
        cur.execute("INSERT INTO reports (analysis_id, case_id) VALUES (?, ?)",
                    (payload.get("analysis_id"), case_id))
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": "attachment; filename=blackchain_forensic_report.pdf"},
    )


@app.get("/api/health")
def health_check():
    return {"status": "ok", "service": "BlackChain API", "time": datetime.now(timezone.utc).isoformat()}
