"""
report_generator.py
Builds a professional forensic PDF report from a completed analysis result.
"""

from __future__ import annotations

import io
from datetime import datetime, timezone

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak,
)

DARK = colors.HexColor("#0b1220")
ACCENT = colors.HexColor("#00d4aa")
RISK_COLORS = {
    "LOW": colors.HexColor("#2ecc71"),
    "MODERATE": colors.HexColor("#f1c40f"),
    "SUSPICIOUS": colors.HexColor("#e67e22"),
    "HIGH": colors.HexColor("#e74c3c"),
    "CRITICAL": colors.HexColor("#c0392b"),
}


def generate_pdf_report(analysis: dict, case_id: str | None = None) -> bytes:
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, topMargin=1.5 * cm, bottomMargin=1.5 * cm,
                             leftMargin=1.8 * cm, rightMargin=1.8 * cm)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleX", parent=styles["Title"], textColor=DARK, fontSize=22)
    h2 = ParagraphStyle("H2", parent=styles["Heading2"], textColor=DARK, spaceBefore=14)
    body = ParagraphStyle("BodyX", parent=styles["BodyText"], fontSize=9.5, leading=13)

    elements = []
    elements.append(Paragraph("BLACKCHAIN", title_style))
    elements.append(Paragraph("AI Email Threat Detection &amp; Digital Forensics Report", styles["Heading3"]))
    elements.append(Spacer(1, 6))

    meta_rows = [
        ["Case ID", case_id or "N/A"],
        ["Analysis Date/Time", datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")],
        ["Risk Score", f"{analysis['risk_score']} / 100"],
        ["Risk Level", analysis["risk_level"]],
        ["Threat Classification", analysis["classification"]],
    ]
    meta_table = Table(meta_rows, colWidths=[5 * cm, 10 * cm])
    meta_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#eef2f7")),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cfd8e3")),
        ("FONTSIZE", (0, 0), (-1, -1), 9.5),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    elements.append(meta_table)
    elements.append(Spacer(1, 10))

    elements.append(Paragraph("Executive Summary", h2))
    elements.append(Paragraph(
        f"This message was assessed as <b>{analysis['risk_summary'].upper()}</b> with a computed risk score of "
        f"<b>{analysis['risk_score']}/100</b> ({analysis['risk_level']}). "
        f"Threat classification: <b>{analysis['classification']}</b>.", body))
    elements.append(Spacer(1, 8))

    elements.append(Paragraph("Why was this flagged? (Explainable findings)", h2))
    exp_rows = [["Indicator", "Detail"]] + [[e["label"], e["detail"]] for e in analysis["explanation"]]
    exp_table = Table(exp_rows, colWidths=[5 * cm, 10 * cm])
    exp_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), DARK),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cfd8e3")),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f7f9fb")]),
    ]))
    elements.append(exp_table)
    elements.append(Spacer(1, 8))

    header = analysis.get("header_analysis", {})
    elements.append(Paragraph("Sender & Header Analysis", h2))
    header_rows = [
        ["From domain", header.get("from_domain", "N/A")],
        ["SPF", header.get("spf", "none")],
        ["DKIM", header.get("dkim", "none")],
        ["DMARC", header.get("dmarc", "none")],
        ["Originating IP", header.get("originating_ip") or "Not available"],
    ]
    ht = Table(header_rows, colWidths=[5 * cm, 10 * cm])
    ht.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#eef2f7")),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cfd8e3")),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
    ]))
    elements.append(ht)
    elements.append(Spacer(1, 8))

    ip_intel = analysis.get("ip_intelligence", {})
    elements.append(Paragraph("Sender IP Intelligence", h2))
    if ip_intel.get("available"):
        elements.append(Paragraph(ip_intel.get("disclaimer", ""), ParagraphStyle(
            "note", parent=body, textColor=colors.HexColor("#8a5a00"), fontSize=8.5)))
        ip_rows = [
            ["IP Address", ip_intel.get("ip", "")],
            ["Country", ip_intel.get("country", "")],
            ["Region/City", f"{ip_intel.get('region','')}, {ip_intel.get('city','')}"],
            ["ISP/Org", ip_intel.get("isp", "")],
            ["ASN", str(ip_intel.get("asn", ""))],
            ["VPN/Proxy/Hosting", "Yes" if ip_intel.get("vpn_or_proxy") else "No"],
        ]
        ipt = Table(ip_rows, colWidths=[5 * cm, 10 * cm])
        ipt.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#eef2f7")),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cfd8e3")),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
        ]))
        elements.append(ipt)
    else:
        elements.append(Paragraph(ip_intel.get("message", "Location unavailable."), body))
    elements.append(Spacer(1, 8))

    elements.append(Paragraph("URL Analysis", h2))
    urls = analysis.get("urls", [])
    if urls:
        url_rows = [["URL", "Domain", "Risk", "Reason"]]
        for u in urls[:15]:
            url_rows.append([
                Paragraph(u["url"][:70], body), u["domain"], u["risk_level"],
                Paragraph("; ".join(u["reasons"])[:150], body),
            ])
        ut = Table(url_rows, colWidths=[5.5 * cm, 3 * cm, 1.8 * cm, 4.7 * cm])
        ut.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), DARK),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cfd8e3")),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ]))
        elements.append(ut)
    else:
        elements.append(Paragraph("No URLs were found in this message.", body))
    elements.append(Spacer(1, 8))

    elements.append(Paragraph("Indicators of Compromise (IOC)", h2))
    iocs = analysis.get("indicators", [])
    if iocs:
        ioc_rows = [["Type", "Value", "Source", "Risk"]]
        for ioc in iocs[:25]:
            ioc_rows.append([ioc["type"], Paragraph(ioc["value"][:60], body), ioc["source"], ioc["risk"]])
        iot = Table(ioc_rows, colWidths=[2 * cm, 7 * cm, 3.5 * cm, 2.5 * cm])
        iot.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), DARK),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cfd8e3")),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
        ]))
        elements.append(iot)
    else:
        elements.append(Paragraph("No indicators extracted.", body))
    elements.append(Spacer(1, 8))

    elements.append(Paragraph("Recommended Actions", h2))
    for i, rec in enumerate(analysis.get("recommendations", []), start=1):
        elements.append(Paragraph(f"{i}. {rec}", body))

    elements.append(Spacer(1, 14))
    elements.append(Paragraph(
        "Disclaimer: This report is generated by an automated, rule-based analysis engine for educational "
        "and awareness purposes. It does not constitute definitive proof of malicious intent and should be "
        "verified by a qualified analyst before action is taken.",
        ParagraphStyle("disclaimer", parent=body, fontSize=7.5, textColor=colors.grey)))

    doc.build(elements)
    return buffer.getvalue()
