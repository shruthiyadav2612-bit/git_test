"""
ioc_extractor.py
Builds a consolidated Indicator-of-Compromise (IOC) table from everything
already extracted during analysis (no new lookups performed here).
"""

from __future__ import annotations


def build_ioc_table(parsed: dict, header_result: dict, url_results: list[dict],
                     attachment_results: list[dict], ip_result: dict) -> list[dict]:
    iocs = []

    if header_result.get("originating_ip"):
        iocs.append({
            "type": "IP",
            "value": header_result["originating_ip"],
            "source": "Received headers",
            "risk": "Medium" if ip_result.get("vpn_or_proxy") else "Info",
            "notes": "Originating IP extracted from mail hop chain." + (
                " Flagged as VPN/proxy/hosting." if ip_result.get("vpn_or_proxy") else ""
            ),
        })

    from_domain = header_result.get("from_domain", "")
    if from_domain:
        iocs.append({
            "type": "Domain",
            "value": from_domain,
            "source": "From header",
            "risk": "Info",
            "notes": "Sender domain.",
        })

    if parsed.get("from_email"):
        iocs.append({
            "type": "Email",
            "value": parsed["from_email"],
            "source": "From header",
            "risk": "Info",
            "notes": "Sender email address.",
        })
    if parsed.get("reply_to_email") and parsed["reply_to_email"] != parsed.get("from_email"):
        iocs.append({
            "type": "Email",
            "value": parsed["reply_to_email"],
            "source": "Reply-To header",
            "risk": "Medium",
            "notes": "Reply-To differs from From address.",
        })

    for url in url_results:
        iocs.append({
            "type": "URL",
            "value": url["url"],
            "source": "Email body",
            "risk": url["risk_level"],
            "notes": "; ".join(url["reasons"][:2]),
        })
        if url["domain"]:
            iocs.append({
                "type": "Domain",
                "value": url["domain"],
                "source": "Extracted from URL",
                "risk": url["risk_level"],
                "notes": "Linked domain.",
            })

    for att in attachment_results:
        if att.get("sha256"):
            iocs.append({
                "type": "Hash",
                "value": att["sha256"],
                "source": f"Attachment: {att['filename']}",
                "risk": att["risk_level"],
                "notes": f"SHA-256 of attachment ({att['extension']}).",
            })

    # De-duplicate identical (type, value) pairs while preserving first occurrence.
    seen = set()
    deduped = []
    for ioc in iocs:
        key = (ioc["type"], ioc["value"])
        if key not in seen:
            seen.add(key)
            deduped.append(ioc)
    return deduped
