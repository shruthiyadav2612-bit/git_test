"""
demo_data.py
Safe, clearly-labeled simulated sample emails for Demo Mode.
None of these reference real people, companies' real infrastructure, or
live malicious infrastructure — all domains/IPs are illustrative examples.
"""

NORMAL_EMAIL = """From: Priya Sharma <priya.sharma@university.edu>
To: student.group@university.edu
Reply-To: priya.sharma@university.edu
Subject: Reminder: Project submission deadline this Friday
Date: Mon, 01 Sep 2025 09:15:00 +0530
Message-ID: <abc123@university.edu>

Hi all,

Just a reminder that the CSP project report is due this Friday by 5 PM.
Please upload your PDF to the shared drive folder. Let me know if you
have any questions.

Thanks,
Priya
"""

PHISHING_EMAIL = """From: "Account Security" <security@paypa1-verify.com>
To: user@example.com
Reply-To: support@secure-verify-team.net
Return-Path: bounce@totally-unrelated-domain.ru
Subject: URGENT: Your account will be suspended within 24 hours
Date: Mon, 01 Sep 2025 03:22:00 +0000
Message-ID: <xyz789@paypa1-verify.com>
Authentication-Results: mx.example.com; spf=fail smtp.mailfrom=paypa1-verify.com; dkim=fail; dmarc=fail
Received: from unknown (unknown [203.0.113.45]) by mx.example.com

Dear Customer,

We have detected unusual sign-in activity on your account. Your account
will be suspended within 24 hours unless you verify your identity
immediately.

Click here to verify your account: http://paypa1-verify-secure.xyz/login?user=confirm

Please enter your password and one-time password (OTP) to confirm your
identity. Failure to respond within 24 hours will result in permanent
account suspension.

Regards,
Account Security Team
"""

BANKING_SCAM_EMAIL = """From: "SBI Bank Alerts" <alerts@sbi-online-verify.tk>
To: customer@example.com
Reply-To: sbi.support@rediffmail.com
Subject: Your bank account has been temporarily blocked
Date: Mon, 01 Sep 2025 11:05:00 +0530
Message-ID: <bank001@sbi-online-verify.tk>
Authentication-Results: mx.example.com; spf=softfail; dkim=none; dmarc=fail

Dear Valued Customer,

Your bank account has been temporarily blocked due to KYC non-compliance.
To avoid permanent closure, please update your bank account details and
UPI ID immediately using the link below:

http://192.0.2.88/sbi-kyc-update.php

This is a final notice. Please act now to avoid legal action.

SBI Online Support
"""

FAKE_JOB_OFFER_EMAIL = """From: "HR Careers Team" <careers@global-hr-recruit.top>
To: applicant@example.com
Reply-To: hr.recruit2025@yandex.com
Subject: Congratulations! Work from home job offer - earn daily income
Date: Mon, 01 Sep 2025 14:40:00 +0000
Message-ID: <job2025@global-hr-recruit.top>

Congratulations!

You have been selected for a work from home part-time job opportunity
with guaranteed daily income. No experience required, high salary,
flexible hours.

A small recruitment fee is required to process your offer letter.
Send your bank details and a processing fee via the link below:

http://bit.ly/job-offer-2025-claim

Act now, limited seats available!

HR Careers Team
"""

DEMO_SAMPLES = {
    "normal": {"label": "Normal email", "raw": NORMAL_EMAIL},
    "phishing": {"label": "Phishing email", "raw": PHISHING_EMAIL},
    "banking_scam": {"label": "Banking scam", "raw": BANKING_SCAM_EMAIL},
    "fake_job_offer": {"label": "Fake job offer", "raw": FAKE_JOB_OFFER_EMAIL},
}
