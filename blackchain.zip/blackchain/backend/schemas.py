from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class AnalyzeRequest(BaseModel):
    raw_email: str = Field(..., description="Pasted raw email text, headers, or body.")
    create_case: bool = False


class CaseCreateRequest(BaseModel):
    analysis_id: Optional[int] = None
    email_summary: str
    risk_level: str
    threat_type: str
    status: str = "New"
    analyst_notes: str = ""


class CaseUpdateRequest(BaseModel):
    status: Optional[str] = None
    analyst_notes: Optional[str] = None
    threat_type: Optional[str] = None


class ReportRequest(BaseModel):
    analysis_id: int
    case_id: Optional[str] = None
