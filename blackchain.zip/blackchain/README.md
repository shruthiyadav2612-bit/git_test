# BLACKCHAIN — AI Email Threat Detection & Digital Forensics Platform

BlackChain analyzes a pasted or uploaded email and produces an explainable
forensic report: sender authentication (SPF/DKIM/DMARC), phishing/scam
language detection, URL risk analysis, attachment metadata, approximate
sender network geolocation, an IOC table, a transparent 0–100 risk score,
and a downloadable PDF report. It also includes basic case management and
a security dashboard.

**This is a rule-based educational/awareness tool.** It never visits links,
never opens or executes attachments, and never claims a sender's exact
physical location — only approximate network-level geolocation, clearly
labeled as such.

---

## 1. Project structure

```
blackchain/
├── frontend/                 # Static HTML/CSS/JS — deploy to Netlify
│   ├── index.html            # Home / Email Analyzer / Results
│   ├── dashboard.html        # Security dashboard + charts
│   ├── cases.html            # Cyber case management
│   ├── css/style.css
│   ├── js/{config,api,analyzer,dashboard,cases}.js
│   └── assets/
├── backend/                  # FastAPI — deploy to Render (or similar)
│   ├── main.py
│   ├── database.py
│   ├── models.py
│   ├── schemas.py
│   ├── analyzer/              # email_parser, header_analyzer, phishing_detector,
│   │                           # url_analyzer, attachment_analyzer, ip_intelligence, risk_engine
│   ├── services/               # ioc_extractor, demo_data, report_generator
│   ├── sample_emails/          # .eml test files (normal / phishing / banking scam / fake job offer)
│   └── requirements.txt
├── netlify.toml
├── render.yaml
├── .env.example
└── .gitignore
```

---

## 2. Run it locally

### Backend

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp ../.env.example .env         # edit values if needed (defaults work locally)
uvicorn main:app --reload --port 8000
```

The API is now at `http://localhost:8000`. Interactive API docs (auto-generated
by FastAPI) are at `http://localhost:8000/docs`.

### Frontend

The frontend is plain static HTML/CSS/JS — no build step. Serve it with any
static file server, for example:

```bash
cd frontend
python3 -m http.server 5500
```

Open `http://localhost:5500`. It talks to the backend at `http://localhost:8000`
automatically (see `js/config.js` — it defaults to localhost when the page
itself is served from localhost).

Try **Demo Mode** on the home page to see the pipeline run end-to-end without
pasting anything.

---

## 3. Deploy the backend (Render)

1. Push this repository to GitHub/GitLab.
2. In Render: **New → Blueprint**, point it at your repo — it will read
   `render.yaml` and create the `blackchain-backend` web service automatically.
   (Alternatively: **New → Web Service**, root directory `backend`,
   build command `pip install -r requirements.txt`,
   start command `uvicorn main:app --host 0.0.0.0 --port $PORT`.)
3. Set environment variables on the service (Render dashboard → Environment):
   - `ALLOWED_ORIGINS` = your Netlify URL, e.g. `https://blackchain-demo.netlify.app`
   - Optionally `IP_INTEL_API_URL` / `IP_INTEL_API_KEY` for a paid geolocation provider
     (otherwise the free `ip-api.com` endpoint is used automatically).
4. Deploy. Note the resulting URL, e.g. `https://blackchain-backend.onrender.com`.
   Confirm it's alive: `GET https://blackchain-backend.onrender.com/api/health`.

> Free-tier Render services sleep after inactivity; the first request after
> sleeping can take 30–60 seconds. The frontend's loading state accounts for this.

---

## 4. Deploy the frontend (Netlify)

1. In Netlify: **Add new site → Import an existing project**, connect the repo.
   `netlify.toml` sets the base directory to `frontend` automatically —
   no build command is needed (it's static files).
2. Before or after deploying, open `frontend/js/config.js` and set:
   ```js
   window.BLACKCHAIN_API_URL = "https://blackchain-backend.onrender.com";
   ```
   Commit and redeploy (or push again — Netlify auto-builds on push).
3. Once live, go back to Render and update `ALLOWED_ORIGINS` to include your
   real Netlify URL, then redeploy the backend so CORS allows it.

**Quick demo without redeploying:** open your Netlify site with
`?api=https://blackchain-backend.onrender.com` appended once — the URL is
saved to the browser's local storage and reused after that.

---

## 5. API reference

Base URL: your backend origin (local: `http://localhost:8000`)

| Method | Path | Description |
|---|---|---|
| POST | `/api/analyze` | Analyze pasted email text. Body: `{ "raw_email": "...", "create_case": false }` |
| POST | `/api/upload` | Analyze an uploaded `.eml`/`.txt` file (multipart form, field `file`) |
| GET | `/api/demo-samples` | List available demo sample keys/labels |
| POST | `/api/demo/{sample_key}` | Run analysis on a built-in demo sample |
| GET | `/api/cases` | List all cases |
| POST | `/api/cases` | Create a case manually |
| GET | `/api/cases/{case_id}` | Get one case |
| PUT | `/api/cases/{case_id}` | Update status / analyst notes / threat type |
| GET | `/api/statistics` | Dashboard aggregate statistics |
| POST | `/api/reports/full` | Generate a PDF report from a full analysis object (used by the frontend right after analysis) |
| POST | `/api/reports` | Regenerate a PDF report from a stored `analysis_id` |
| GET | `/api/health` | Health check |

Full interactive docs (Swagger UI) are always available at `/docs` on the
running backend, and ReDoc at `/redoc`.

### Example: `POST /api/analyze` response shape

```json
{
  "risk_score": 78,
  "risk_level": "HIGH",
  "classification": "Credential Theft",
  "sender": { "from_email": "...", "from_domain": "...", "...": "..." },
  "authentication": { "spf": "fail", "dkim": "fail", "dmarc": "fail" },
  "header_analysis": { "hops": [], "findings": [], "originating_ip": "..." },
  "urls": [ { "url": "...", "domain": "...", "risk_level": "High", "reasons": ["..."] } ],
  "attachments": [],
  "ip_intelligence": { "available": true, "country": "...", "disclaimer": "Approximate network geolocation — not the sender's exact physical location." },
  "indicators": [ { "type": "URL", "value": "...", "source": "...", "risk": "High" } ],
  "explanation": [ { "label": "Authentication failure", "detail": "..." } ],
  "recommendations": [ "Do not click any links...", "..." ]
}
```

---

## 6. Sample test emails

`backend/sample_emails/` contains four `.eml` files matching Demo Mode:
`normal.eml`, `phishing.eml`, `banking_scam.eml`, `fake_job_offer.eml`. All
domains and addresses in these samples are fictional/illustrative — none
point at real infrastructure. Upload any of them through the analyzer to
see the full pipeline run on a file instead of pasted text.

---

## 7. Privacy & safety notes

- No links are ever fetched by the backend; URL "analysis" is purely
  pattern-based on the URL string itself.
- Attachments are never opened or executed — only metadata and a SHA-256
  hash are computed from bytes already present in the parsed email.
- IP geolocation is approximate and network-level only (ISP/city-level via
  a public IP), never a claim about a person's exact physical location.
- Avoid pasting real passwords, OTPs, or private keys into the analyzer —
  a notice to this effect is shown on the analyzer page.
- Only the minimum data needed for statistics/case management is stored
  (see `backend/database.py`); full raw email bodies are not persisted to
  the database.

---

## 8. Notes on the database

SQLite is used out of the box (`backend/blackchain.db`, auto-created on
first run) so the project runs with zero external setup. The schema
(`emails`, `analyses`, `cases`, `indicators`, `reports`, `users` — see
`database.py`) uses plain SQL, so migrating to PostgreSQL in production
mainly means swapping the connection layer (e.g. to `psycopg2`/`asyncpg`)
and adjusting the autoincrement syntax (`SERIAL`/`IDENTITY` instead of
`AUTOINCREMENT`); the table definitions themselves are portable.

---

## 9. Known limitations (by design, for safety/scope)

- Phishing/scam detection is rule-based (keyword/pattern matching); it is
  a first-pass signal, not a certainty claim — every result ships with an
  explanation, never a bare probability.
- No live URL/attachment reputation API is wired in by default (env vars
  are provided in `.env.example` for `URL_REPUTATION_API_*` and
  `MALWARE_SCAN_API_*` if you want to extend `url_analyzer.py` /
  `attachment_analyzer.py` to call one).
- `.msg` (Outlook binary format) parsing is not implemented — `.eml` and
  `.txt` are supported, which covers the vast majority of exported/forwarded
  emails.
