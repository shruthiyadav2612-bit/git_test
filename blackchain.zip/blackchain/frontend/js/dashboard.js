/**
 * dashboard.js
 * Fetches /api/statistics and renders stat cards + Chart.js visualizations.
 */

const CHART_COLORS = ["#2be8b0", "#4da6ff", "#e8c93a", "#f0973d", "#f0553d", "#ff2d55", "#9b7cff", "#6d7c8c"];

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str == null ? "" : String(str);
  return div.innerHTML;
}

function statCard(num, label, tone = "") {
  return `<div class="stat-card ${tone}"><div class="stat-num">${num}</div><div class="stat-label">${escapeHtml(label)}</div></div>`;
}

function baseChartOptions(extra = {}) {
  return Object.assign({
    responsive: true,
    plugins: { legend: { labels: { color: "#a9b8c7", font: { family: "IBM Plex Mono", size: 11 } } } },
    scales: {
      x: { ticks: { color: "#6d7c8c" }, grid: { color: "#1a2532" } },
      y: { ticks: { color: "#6d7c8c" }, grid: { color: "#1a2532" }, beginAtZero: true },
    },
  }, extra);
}

async function loadDashboard() {
  const statusEl = document.getElementById("dashStatus");
  statusEl.innerHTML = `<div class="loading-line"><span class="spinner"></span> Loading statistics…</div>`;

  try {
    const stats = await BlackChainAPI.getStatistics();
    statusEl.innerHTML = "";

    if (!stats.has_data) {
      statusEl.innerHTML = `<div class="panel empty-state"><div class="ico">▤</div>Insufficient historical data. Analyze an email or run a demo sample to populate this dashboard.</div>`;
    }

    const cards = document.getElementById("statCards");
    cards.innerHTML = [
      statCard(stats.total_emails_analyzed, "Total Emails Analyzed", "accent"),
      statCard(stats.suspicious_emails, "Suspicious Emails", "warn"),
      statCard(stats.high_risk_emails, "High Risk Emails", "danger"),
      statCard(stats.phishing_detected, "Phishing Detected", "warn"),
      statCard(stats.scam_detected, "Scam Detected", "warn"),
      statCard(stats.malicious_urls, "Malicious URLs", "danger"),
      statCard(stats.cases_created, "Cases Created"),
      statCard(stats.reports_generated, "Reports Generated"),
    ].join("");

    renderCategoryChart(stats.threats_by_category || {});
    renderRiskChart(stats.risk_distribution || {});
    renderTimeChart(stats.emails_over_time || []);
    renderTopIndicators(stats.top_indicators || []);
  } catch (err) {
    statusEl.innerHTML = `<div class="error-banner">⚠ Could not load statistics: ${escapeHtml(err.message)}</div>`;
  }
}

function renderCategoryChart(data) {
  const ctx = document.getElementById("categoryChart");
  const labels = Object.keys(data);
  const values = Object.values(data);
  if (!labels.length) { ctx.parentElement.insertAdjacentHTML("beforeend", `<p style="color:var(--text-dim); font-size:13px;">No classified emails yet.</p>`); return; }
  new Chart(ctx, {
    type: "doughnut",
    data: { labels, datasets: [{ data: values, backgroundColor: CHART_COLORS, borderColor: "#0c121c", borderWidth: 2 }] },
    options: baseChartOptions({ scales: undefined }),
  });
}

function renderRiskChart(data) {
  const ctx = document.getElementById("riskChart");
  const order = ["LOW", "MODERATE", "SUSPICIOUS", "HIGH", "CRITICAL"];
  const colors = { LOW: "#34c77b", MODERATE: "#e8c93a", SUSPICIOUS: "#f0973d", HIGH: "#f0553d", CRITICAL: "#ff2d55" };
  const labels = order.filter(k => data[k]);
  const values = labels.map(k => data[k]);
  if (!labels.length) { ctx.parentElement.insertAdjacentHTML("beforeend", `<p style="color:var(--text-dim); font-size:13px;">No risk data yet.</p>`); return; }
  new Chart(ctx, {
    type: "bar",
    data: { labels, datasets: [{ label: "Emails", data: values, backgroundColor: labels.map(l => colors[l]) }] },
    options: baseChartOptions({ plugins: { legend: { display: false } } }),
  });
}

function renderTimeChart(data) {
  const ctx = document.getElementById("timeChart");
  if (!data.length) { ctx.parentElement.insertAdjacentHTML("beforeend", `<p style="color:var(--text-dim); font-size:13px;">No time-series data yet.</p>`); return; }
  new Chart(ctx, {
    type: "line",
    data: {
      labels: data.map(d => d.date),
      datasets: [{ label: "Emails Analyzed", data: data.map(d => d.count), borderColor: "#2be8b0", backgroundColor: "rgba(43,232,176,0.12)", fill: true, tension: 0.3 }],
    },
    options: baseChartOptions(),
  });
}

function renderTopIndicators(items) {
  const el = document.getElementById("topIndicators");
  if (!items.length) { el.innerHTML = `<p style="color:var(--text-dim); font-size:13px;">No high/medium risk indicators recorded yet.</p>`; return; }
  el.innerHTML = `<div class="table-wrap"><table>
    <tr><th>Type</th><th>Detail</th><th>Occurrences</th></tr>
    ${items.map(i => `<tr><td><span class="badge-pill">${escapeHtml(i.type)}</span></td><td style="font-size:12.5px;">${escapeHtml(i.notes || "—")}</td><td>${i.count}</td></tr>`).join("")}
  </table></div>`;
}

loadDashboard();
