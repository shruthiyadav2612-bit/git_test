/**
 * config.js
 * Resolves the backend API base URL without hard-coding localhost.
 *
 * Resolution order:
 *   1. `?api=https://your-backend.onrender.com` query param (saved to localStorage — handy for demos)
 *   2. A value previously saved to localStorage
 *   3. window.BLACKCHAIN_API_URL set below (edit this line after deploying your backend)
 *   4. Same-origin fallback + local dev fallback (only used if nothing else is set)
 */
(function () {
  // 👉 After deploying the FastAPI backend (e.g. to Render), put its URL here:
  window.BLACKCHAIN_API_URL = window.BLACKCHAIN_API_URL || "https://your-backend-service.onrender.com";

  const params = new URLSearchParams(window.location.search);
  const fromQuery = params.get("api");

  if (fromQuery) {
    localStorage.setItem("blackchain_api_base", fromQuery);
  }

  const fromStorage = localStorage.getItem("blackchain_api_base");
  const isLocalHost = ["localhost", "127.0.0.1"].includes(window.location.hostname);

  window.API_BASE_URL =
    fromQuery ||
    fromStorage ||
    (window.BLACKCHAIN_API_URL && !window.BLACKCHAIN_API_URL.includes("your-backend-service")
      ? window.BLACKCHAIN_API_URL
      : isLocalHost
      ? "http://localhost:8000"
      : window.BLACKCHAIN_API_URL);
})();
