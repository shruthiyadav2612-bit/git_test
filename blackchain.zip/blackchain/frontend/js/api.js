/**
 * api.js
 * Thin fetch wrapper for the BlackChain backend, with friendly error
 * messages instead of raw stack traces surfaced to the user.
 */

const BlackChainAPI = (() => {
  function base() {
    return (window.API_BASE_URL || "").replace(/\/$/, "");
  }

  async function handle(res) {
    if (!res.ok) {
      let detail = `Request failed (${res.status})`;
      try {
        const body = await res.json();
        detail = body.detail || detail;
      } catch (_) {
        /* non-JSON error body */
      }
      throw new Error(detail);
    }
    return res;
  }

  async function withTimeout(promise, ms = 20000) {
    let timer;
    const timeout = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error("The backend took too long to respond. It may be waking up from sleep — please try again in a few seconds.")), ms);
    });
    try {
      return await Promise.race([promise, timeout]);
    } finally {
      clearTimeout(timer);
    }
  }

  async function analyzeEmail(rawEmail, createCase = false) {
    const res = await withTimeout(fetch(`${base()}/api/analyze`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ raw_email: rawEmail, create_case: createCase }),
    }));
    await handle(res);
    return res.json();
  }

  async function uploadEmail(file, createCase = false) {
    const form = new FormData();
    form.append("file", file);
    const res = await withTimeout(fetch(`${base()}/api/upload?create_case=${createCase}`, {
      method: "POST",
      body: form,
    }));
    await handle(res);
    return res.json();
  }

  async function runDemo(sampleKey) {
    const res = await withTimeout(fetch(`${base()}/api/demo/${sampleKey}`, { method: "POST" }));
    await handle(res);
    return res.json();
  }

  async function getDemoSamples() {
    const res = await withTimeout(fetch(`${base()}/api/demo-samples`));
    await handle(res);
    return res.json();
  }

  async function getStatistics() {
    const res = await withTimeout(fetch(`${base()}/api/statistics`));
    await handle(res);
    return res.json();
  }

  async function listCases() {
    const res = await withTimeout(fetch(`${base()}/api/cases`));
    await handle(res);
    return res.json();
  }

  async function updateCase(caseId, payload) {
    const res = await withTimeout(fetch(`${base()}/api/cases/${caseId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }));
    await handle(res);
    return res.json();
  }

  async function downloadFullReport(analysis) {
    const res = await withTimeout(fetch(`${base()}/api/reports/full`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(analysis),
    }), 30000);
    await handle(res);
    return res.blob();
  }

  async function health() {
    const res = await fetch(`${base()}/api/health`);
    await handle(res);
    return res.json();
  }

  return { analyzeEmail, uploadEmail, runDemo, getDemoSamples, getStatistics, listCases, updateCase, downloadFullReport, health };
})();
