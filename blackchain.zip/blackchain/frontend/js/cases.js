/**
 * cases.js
 * Lists cases from /api/cases and allows inline status/notes updates via
 * PUT /api/cases/{case_id}.
 */

const STATUS_OPTIONS = ["New", "Investigating", "Confirmed Threat", "False Positive", "Closed"];

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str == null ? "" : String(str);
  return div.innerHTML;
}

function riskBadge(level) {
  return `<span class="risk-badge risk-${level}">${escapeHtml(level)}</span>`;
}

async function loadCases() {
  const status = document.getElementById("casesStatus");
  const list = document.getElementById("casesList");
  status.innerHTML = `<div class="loading-line"><span class="spinner"></span> Loading cases…</div>`;
  list.innerHTML = "";

  try {
    const data = await BlackChainAPI.listCases();
    status.innerHTML = "";

    if (!data.cases.length) {
      list.innerHTML = `<div class="panel empty-state"><div class="ico">▥</div>No cases yet. Analyze an email and check "Automatically open a Cyber Case" to create one.</div>`;
      return;
    }

    list.innerHTML = data.cases.map(renderCaseCard).join("");
    data.cases.forEach(c => attachHandlers(c.case_id));
  } catch (err) {
    status.innerHTML = `<div class="error-banner">⚠ Could not load cases: ${escapeHtml(err.message)}</div>`;
  }
}

function renderCaseCard(c) {
  return `
  <div class="panel" style="margin-bottom:14px;" id="case-${c.case_id}">
    <div class="section-title">
      <h3 class="mono">${escapeHtml(c.case_id)}</h3>
      ${riskBadge(c.risk_level)}
    </div>
    <table>
      <tr><th>Email</th><td>${escapeHtml(c.email_summary || "(no subject)")}</td></tr>
      <tr><th>Threat Type</th><td>${escapeHtml(c.threat_type || "Unknown")}</td></tr>
      <tr><th>Created</th><td>${escapeHtml(c.created_at)}</td></tr>
    </table>
    <div style="margin-top:12px; display:grid; grid-template-columns: 180px 1fr; gap:12px;">
      <div>
        <label style="font-size:11.5px; color:var(--text-dim);">Status</label>
        <select class="status-select" data-case="${c.case_id}" id="status-${c.case_id}">
          ${STATUS_OPTIONS.map(s => `<option value="${s}" ${s === c.status ? "selected" : ""}>${s}</option>`).join("")}
        </select>
      </div>
      <div>
        <label style="font-size:11.5px; color:var(--text-dim);">Analyst Notes</label>
        <textarea class="notes-area" id="notes-${c.case_id}">${escapeHtml(c.analyst_notes || "")}</textarea>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn btn-primary" data-save="${c.case_id}">Save Changes</button>
      <span class="save-msg" id="save-msg-${c.case_id}" style="font-size:12px; color:var(--accent); align-self:center;"></span>
    </div>
  </div>`;
}

function attachHandlers(caseId) {
  const btn = document.querySelector(`[data-save="${caseId}"]`);
  btn.addEventListener("click", async () => {
    btn.disabled = true;
    const status = document.getElementById(`status-${caseId}`).value;
    const notes = document.getElementById(`notes-${caseId}`).value;
    const msg = document.getElementById(`save-msg-${caseId}`);
    try {
      await BlackChainAPI.updateCase(caseId, { status, analyst_notes: notes });
      msg.textContent = "✓ Saved";
      setTimeout(() => (msg.textContent = ""), 2000);
    } catch (err) {
      msg.style.color = "var(--risk-critical)";
      msg.textContent = `⚠ ${err.message}`;
    } finally {
      btn.disabled = false;
    }
  });
}

document.getElementById("refreshBtn").addEventListener("click", loadCases);
loadCases();
