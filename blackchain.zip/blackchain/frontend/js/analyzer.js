/**
 * analyzer.js
 * Drives the paste/upload → analyze → render-results flow on index.html.
 */

let currentFile = null;
let lastAnalysis = null;

const emailInput = document.getElementById("emailInput");
const tabPaste = document.getElementById("tabPaste");
const tabUpload = document.getElementById("tabUpload");
const pasteTab = document.getElementById("pasteTab");
const uploadTab = document.getElementById("uploadTab");
const dropzone = document.getElementById("dropzone");
const fileInput = document.getElementById("fileInput");
const fileNameEl = document.getElementById("fileName");
const analyzeBtn = document.getElementById("analyzeBtn");
const clearBtn = document.getElementById("clearBtn");
const downloadBtn = document.getElementById("downloadBtn");
const createCaseToggle = document.getElementById("createCaseToggle");
const statusArea = document.getElementById("statusArea");
const resultsArea = document.getElementById("resultsArea");
const demoRow = document.getElementById("demoRow");

let activeTab = "paste";

function setTab(tab) {
  activeTab = tab;
  tabPaste.classList.toggle("active", tab === "paste");
  tabUpload.classList.toggle("active", tab === "upload");
  pasteTab.style.display = tab === "paste" ? "block" : "none";
  uploadTab.style.display = tab === "upload" ? "block" : "none";
}
tabPaste.addEventListener("click", () => setTab("paste"));
tabUpload.addEventListener("click", () => setTab("upload"));

dropzone.addEventListener("click", () => fileInput.click());
dropzone.addEventListener("dragover", (e) => { e.preventDefault(); dropzone.classList.add("dragover"); });
dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragover"));
dropzone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropzone.classList.remove("dragover");
  if (e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]);
});
fileInput.addEventListener("change", (e) => { if (e.target.files.length) handleFile(e.target.files[0]); });

function handleFile(file) {
  if (file.size > 5 * 1024 * 1024) {
    showError("File too large. Maximum size is 5 MB.");
    return;
  }
  currentFile = file;
  fileNameEl.textContent = `Selected: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
}

clearBtn.addEventListener("click", () => {
  emailInput.value = "";
  currentFile = null;
  fileNameEl.textContent = "";
  fileInput.value = "";
  statusArea.innerHTML = "";
  resultsArea.innerHTML = "";
  downloadBtn.disabled = true;
  lastAnalysis = null;
});

function showError(message) {
  statusArea.innerHTML = `<div class="error-banner">⚠ ${escapeHtml(message)}</div>`;
}

function showLoading(message) {
  statusArea.innerHTML = `<div class="loading-line"><span class="spinner"></span> ${escapeHtml(message)}</div>`;
}

function clearStatus() {
  statusArea.innerHTML = "";
}

analyzeBtn.addEventListener("click", async () => {
  resultsArea.innerHTML = "";
  downloadBtn.disabled = true;

  if (activeTab === "upload" && !currentFile && !emailInput.value.trim()) {
    showError("Please upload a file or paste an email first.");
    return;
  }
  if (activeTab === "paste" && !emailInput.value.trim()) {
    showError("Please paste an email, headers, or message text first.");
    return;
  }

  analyzeBtn.disabled = true;
  showLoading("Parsing headers, scanning language, checking URLs and reputation…");

  try {
    let result;
    if (activeTab === "upload" && currentFile) {
      result = await BlackChainAPI.uploadEmail(currentFile, createCaseToggle.checked);
    } else {
      result = await BlackChainAPI.analyzeEmail(emailInput.value, createCaseToggle.checked);
    }
    lastAnalysis = result;
    clearStatus();
    renderResults(result);
    downloadBtn.disabled = false;
  } catch (err) {
    showError(err.message || "Something went wrong while analyzing this email. Please try again.");
  } finally {
    analyzeBtn.disabled = false;
  }
});

downloadBtn.addEventListener("click", async () => {
  if (!lastAnalysis) return;
  downloadBtn.disabled = true;
  downloadBtn.textContent = "Generating…";
  try {
    const blob = await BlackChainAPI.downloadFullReport(lastAnalysis);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `blackchain_report_${lastAnalysis.analysis_id || "case"}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  } catch (err) {
    showError(err.message || "Could not generate the report.");
  } finally {
    downloadBtn.disabled = false;
    downloadBtn.textContent = "Download Report";
  }
});

// ---------------- Demo mode ----------------
async function loadDemoSamples() {
  try {
    const samples = await BlackChainAPI.getDemoSamples();
    demoRow.innerHTML = "";
    Object.entries(samples).forEach(([key, meta]) => {
      const chip = document.createElement("button");
      chip.className = "demo-chip";
      chip.textContent = `▶ ${meta.label}`;
      chip.addEventListener("click", () => runDemo(key, meta.label));
      demoRow.appendChild(chip);
    });
  } catch (err) {
    demoRow.innerHTML = `<span style="font-size:12px;color:var(--text-dim);">Demo samples unavailable — backend not reachable yet.</span>`;
  }
}

async function runDemo(key, label) {
  resultsArea.innerHTML = "";
  downloadBtn.disabled = true;
  showLoading(`Running simulated example: ${label}…`);
  try {
    const result = await BlackChainAPI.runDemo(key);
    lastAnalysis = result;
    clearStatus();
    renderResults(result, true);
    downloadBtn.disabled = false;
  } catch (err) {
    showError(err.message || "Could not run the demo sample.");
  }
}
loadDemoSamples();

// ---------------- Rendering ----------------
function riskColorVar(level) {
  return {
    LOW: "var(--risk-low)", MODERATE: "var(--risk-moderate)", SUSPICIOUS: "var(--risk-suspicious)",
    HIGH: "var(--risk-high)", CRITICAL: "var(--risk-critical)",
  }[level] || "var(--risk-moderate)";
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str == null ? "" : String(str);
  return div.innerHTML;
}

function renderResults(r, isDemo = false) {
  const color = riskColorVar(r.risk_level);
  const sender = r.sender || {};
  const auth = r.authentication || {};
  const header = r.header_analysis || {};
  const ip = r.ip_intelligence || {};

  let html = "";

  if (isDemo) {
    html += `<div class="badge-pill" style="margin-bottom:12px; display:inline-block;">🧪 Simulated demo example — not a real analyzed email</div>`;
  }

  // --- Risk summary ---
  html += `
  <section class="panel section">
    <div class="section-title"><h3>Forensic Report — Executive Summary</h3>
      ${r.case_id ? `<span class="badge-pill">${escapeHtml(r.case_id)}</span>` : ""}
    </div>
    <div class="score-wrap">
      <div class="score-num" style="color:${color}">${r.risk_score}</div>
      <div style="flex:1;">
        <div class="score-meter"><div class="score-fill" style="width:${r.risk_score}%; background:${color};"></div></div>
        <div style="margin-top:8px; display:flex; gap:10px; align-items:center;">
          <span class="risk-badge risk-${r.risk_level}">${r.risk_level} — ${escapeHtml(r.risk_summary)}</span>
          <span class="badge-pill">${escapeHtml(r.classification)}</span>
        </div>
      </div>
    </div>
  </section>`;

  // --- Explainable checklist ---
  html += `
  <section class="panel section">
    <div class="section-title"><h3>Why was this email flagged?</h3></div>
    <ul class="checklist">
      ${(r.explanation || []).map(e => `<li><span class="mark">✓</span><div><strong style="color:var(--text-hi);">${escapeHtml(e.label)}</strong><br/><span style="color:var(--text-dim); font-size:12.5px;">${escapeHtml(e.detail)}</span></div></li>`).join("")}
    </ul>
  </section>`;

  // --- Sender + Auth two-col ---
  html += `
  <section class="section two-col">
    <div class="panel">
      <div class="section-title"><h3>Sender Intelligence</h3></div>
      <table>
        <tr><th>Display name</th><td>${escapeHtml(sender.from_name || "—")}</td></tr>
        <tr><th>From address</th><td class="mono-cell">${escapeHtml(sender.from_email || "—")}</td></tr>
        <tr><th>Domain</th><td class="mono-cell">${escapeHtml(sender.from_domain || "—")}</td></tr>
        <tr><th>Reply-To</th><td class="mono-cell">${escapeHtml(sender.reply_to_email || "—")}</td></tr>
        <tr><th>Return-Path</th><td class="mono-cell">${escapeHtml(sender.return_path_email || "—")}</td></tr>
        <tr><th>Subject</th><td>${escapeHtml(sender.subject || "—")}</td></tr>
        <tr><th>Date</th><td>${escapeHtml(sender.date || "—")}</td></tr>
      </table>
    </div>
    <div class="panel">
      <div class="section-title"><h3>Authentication</h3></div>
      <table>
        <tr><th>SPF</th><td>${authBadge(auth.spf)}</td></tr>
        <tr><th>DKIM</th><td>${authBadge(auth.dkim)}</td></tr>
        <tr><th>DMARC</th><td>${authBadge(auth.dmarc)}</td></tr>
      </table>
      <div class="section-title" style="margin-top:16px;"><h3>Sender IP Intelligence</h3></div>
      ${renderIpIntel(ip)}
    </div>
  </section>`;

  // --- Header forensics / hop flow ---
  html += `
  <section class="panel section">
    <div class="section-title"><h3>Forensic Header Analysis</h3></div>
    <div class="hop-flow">
      <span class="hop-node">Sender</span><span class="hop-arrow">→</span>
      ${(header.hops || []).map(h => `<span class="hop-node">${escapeHtml(h.by)}</span><span class="hop-arrow">→</span>`).join("")}
      <span class="hop-node">Recipient</span>
    </div>
    <div class="table-wrap">
      <table>
        <tr><th>Message-ID</th><td class="mono-cell">${escapeHtml(header.message_id || "—")}</td></tr>
        <tr><th>Originating IP</th><td class="mono-cell">${escapeHtml(header.originating_ip || "Not available")}</td></tr>
      </table>
    </div>
    ${(header.findings || []).length ? `
      <div style="margin-top:12px;">
        ${header.findings.map(f => `<div style="font-size:12.5px; margin-bottom:6px;"><span class="risk-badge risk-${f.severity === 'high' ? 'HIGH' : f.severity === 'medium' ? 'MODERATE' : 'LOW'}">${f.severity}</span> ${escapeHtml(f.message)}</div>`).join("")}
      </div>` : `<p style="font-size:12.5px; color:var(--text-dim); margin-top:10px;">No header inconsistencies detected.</p>`}
  </section>`;

  // --- URL table ---
  html += `
  <section class="panel section">
    <div class="section-title"><h3>URL Analysis</h3><span class="badge-pill">${(r.urls || []).length} link(s) found</span></div>
    ${renderUrlTable(r.urls || [])}
  </section>`;

  // --- Attachments ---
  html += `
  <section class="panel section">
    <div class="section-title"><h3>Attachment Analysis</h3><span class="badge-pill">${(r.attachments || []).length} attachment(s)</span></div>
    ${renderAttachmentTable(r.attachments || [])}
  </section>`;

  // --- IOC table ---
  html += `
  <section class="panel section">
    <div class="section-title"><h3>Indicators of Compromise (IOC)</h3><span class="badge-pill">${(r.indicators || []).length} indicators</span></div>
    ${renderIocTable(r.indicators || [])}
  </section>`;

  // --- Recommended actions ---
  html += `
  <section class="panel section">
    <div class="section-title"><h3>Recommended Actions</h3></div>
    <ol style="padding-left:20px; font-size:13.5px; color:var(--text-mid);">
      ${(r.recommendations || []).map(rec => `<li style="margin-bottom:6px;">${escapeHtml(rec)}</li>`).join("")}
    </ol>
  </section>`;

  resultsArea.innerHTML = html;
  resultsArea.scrollIntoView({ behavior: "smooth", block: "start" });
}

function authBadge(value) {
  const v = (value || "none").toLowerCase();
  const level = v === "pass" ? "LOW" : v === "none" ? "MODERATE" : "HIGH";
  return `<span class="risk-badge risk-${level}">${escapeHtml(v)}</span>`;
}

function renderIpIntel(ip) {
  if (!ip || !ip.available) {
    return `<p style="font-size:12.5px; color:var(--text-dim);">${escapeHtml(ip && ip.message ? ip.message : "Location unavailable.")}</p>`;
  }
  return `
    <p style="font-size:11px; color:var(--risk-moderate); margin-bottom:8px;">${escapeHtml(ip.disclaimer)}</p>
    <table>
      <tr><th>IP</th><td class="mono-cell">${escapeHtml(ip.ip)}</td></tr>
      <tr><th>Country</th><td>${escapeHtml(ip.country || "—")}</td></tr>
      <tr><th>Region/City</th><td>${escapeHtml(ip.region || "—")}, ${escapeHtml(ip.city || "—")}</td></tr>
      <tr><th>ISP/Org</th><td>${escapeHtml(ip.isp || "—")}</td></tr>
      <tr><th>ASN</th><td class="mono-cell">${escapeHtml(ip.asn || "—")}</td></tr>
      <tr><th>VPN/Proxy/Hosting</th><td>${ip.vpn_or_proxy ? '<span class="risk-badge risk-MODERATE">possible</span>' : '<span class="risk-badge risk-LOW">no</span>'}</td></tr>
    </table>`;
}

function renderUrlTable(urls) {
  if (!urls.length) return `<p style="font-size:13px; color:var(--text-dim);">No URLs were found in this message.</p>`;
  return `<div class="table-wrap"><table>
    <tr><th>URL</th><th>Domain</th><th>Risk</th><th>Reason</th></tr>
    ${urls.map(u => `
      <tr>
        <td class="mono-cell" style="max-width:260px;">${escapeHtml(u.url)}</td>
        <td class="mono-cell">${escapeHtml(u.domain)}</td>
        <td><span class="risk-badge risk-${u.risk_level}">${u.risk_level}</span></td>
        <td style="font-size:12px;">${escapeHtml(u.reasons.join("; "))}</td>
      </tr>`).join("")}
  </table></div>`;
}

function renderAttachmentTable(atts) {
  if (!atts.length) return `<p style="font-size:13px; color:var(--text-dim);">No attachments found in this message.</p>`;
  return `<div class="table-wrap"><table>
    <tr><th>Filename</th><th>Ext</th><th>MIME</th><th>Size</th><th>SHA-256</th><th>Risk</th></tr>
    ${atts.map(a => `
      <tr>
        <td>${escapeHtml(a.filename)}</td>
        <td class="mono-cell">${escapeHtml(a.extension)}</td>
        <td style="font-size:12px;">${escapeHtml(a.mime_type)}</td>
        <td>${(a.size_bytes / 1024).toFixed(1)} KB</td>
        <td class="mono-cell" style="max-width:160px;">${escapeHtml((a.sha256 || "—").slice(0, 24))}${a.sha256 ? "…" : ""}</td>
        <td><span class="risk-badge risk-${a.risk_level}">${a.risk_level}</span></td>
      </tr>`).join("")}
  </table></div>`;
}

function renderIocTable(iocs) {
  if (!iocs.length) return `<p style="font-size:13px; color:var(--text-dim);">No indicators extracted.</p>`;
  return `<div class="table-wrap"><table>
    <tr><th>Type</th><th>Value</th><th>Source</th><th>Risk</th><th>Notes</th></tr>
    ${iocs.map(i => `
      <tr>
        <td><span class="badge-pill">${escapeHtml(i.type)}</span></td>
        <td class="mono-cell" style="max-width:220px;">${escapeHtml(i.value)}</td>
        <td style="font-size:12px;">${escapeHtml(i.source)}</td>
        <td><span class="risk-badge risk-${i.risk}">${escapeHtml(i.risk)}</span></td>
        <td style="font-size:12px;">${escapeHtml(i.notes)}</td>
      </tr>`).join("")}
  </table></div>`;
}
